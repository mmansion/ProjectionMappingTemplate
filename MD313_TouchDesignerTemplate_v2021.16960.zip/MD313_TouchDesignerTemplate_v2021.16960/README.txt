1. Unzip folder "MD313_ProjectTemplate"

2. Rename root folder with your project title and name. Example:

"ProjectTitle_MMansion"

3. Rename toe file in same fashion

"ProjectTitle_MMansion.toe"

Your project should look like this:

ProjectTitle_MMansion / 
- ProjectTitle_MMansion.toe
- assets/

